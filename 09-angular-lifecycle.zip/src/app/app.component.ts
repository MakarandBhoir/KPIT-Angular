import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  parentMsg: string = "Hey Child component!!!"
  flag: boolean = true;

  changeFlag(): void {
    this.flag = !this.flag;
  }
}
