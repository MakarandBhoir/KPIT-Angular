import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrl: './message.component.css'
})
export class MessageComponent implements OnInit, OnDestroy, OnChanges {
  @Input() message: string = ''

  constructor() {
    console.log('Message component object is created.')
  }
  ngOnInit(): void {
    console.log('Message component is created.')
  }
  ngOnDestroy(): void {
    console.log('Message component is deleted.')
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log('Message component is updated.')
  }
}
